const API_TOKEN = "{Dienvaoapicuabn}"; // Api token trên web OMOcaptcha.com
const DELAY_CLICK = 100; // Khoảng cách click (mili giây)
const LOOP = true; // Để true sẽ giải đến khi thành công