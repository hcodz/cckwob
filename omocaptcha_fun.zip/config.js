const API_TOKEN = "gl5sa9xx6yJ6OnmDUqBdlsNvYIYo6eAx5RBcOld2eR3z5y4N8WqcGn4Wlkk2QXHQrMJ6jUwjqzsY7ti3"; // Api token trên web OMOcaptcha.com
const DELAY_CLICK = 3000; // Khoảng cách click (mili giây)
const LOOP = true; // Để true sẽ giải đến khi thành công